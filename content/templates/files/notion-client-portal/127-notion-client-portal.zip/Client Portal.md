# Welcome, [Client name]

*Your project home with [Your business]. Everything we're doing together lives on this page.*

> **For you, [Your name]:** keep this page as your master copy. For each new client, duplicate it, rename it, fill in the brackets and share it with them. Delete this box before you share.

## Welcome

Hi [Client name], thanks for choosing [Your business]. This page has what's included, the plan, your files and the tasks we each own. Bookmark it, and check here before you email so nothing gets lost.

## What's included

**Your package:** [Your offer]

- [What's included, item 1]
- [What's included, item 2]
- [What's included, item 3]

**Not included:** [anything people often assume is included]. Ask if you want it added.

## Timeline

| Step | What happens | Who | Target date |
|---|---|---|---|
| 1. Kickoff | We meet, agree on goals and dates | Both | [date] |
| 2. Your homework | You send the things listed in Shared Tasks | You | [date] |
| 3. First version | We share the first draft or first session | [Your business] | [date] |
| 4. Feedback | You reply with changes in one list | You | [date] |
| 5. Wrap-up | Final version, handover and next steps | Both | [date] |

Dates move if a step is waiting on either of us. We'll update this table when they do.

## Files and links

| What | Link |
|---|---|
| Agreement | [link] |
| Invoice and receipts | [link] |
| Shared folder | [link] |
| Notes from our calls | [link] |
| Final files | [link, added at wrap-up] |

## Shared tasks

Everything either of us needs to do is in [Shared Tasks](Client%20Portal/Shared%20Tasks.csv). Filter by Owner to see yours. Tick it off when it's done.

## How to reach [Your business]

- **Email:** [you@yourbusiness.com]
- **Phone or text:** [your phone]
- **Book a call:** [your booking link]
- **Website:** [yourwebsite.com]
- **Replies:** [within one business day, Monday to Friday]

## How we work together

- One list of feedback per round works better than many small messages.
- If something is unclear, ask. A short question now saves a long fix later.
- Each step waits on the one before it, so a late task can move the dates.

*Page set up [date]*
