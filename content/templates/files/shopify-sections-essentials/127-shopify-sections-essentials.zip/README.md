# Shopify sections: essentials pack

Eight sections for any Online Store 2.0 theme, including Dawn. Each one is a single `.liquid` file you add to your theme, then place and edit in the theme editor like any built-in section.

| File | What it does |
|---|---|
| `sections/hero-split.liquid` | Image beside a headline, a short paragraph and two buttons. Image left or right, three image shapes, three heading sizes. |
| `sections/trust-bar.liquid` | Up to 6 small icons with short lines (checkout, shipping, returns, support). Ten built-in icons or your own. |
| `sections/feature-grid.liquid` | A heading plus 3 to 6 feature cards with an icon or image, a title and text. 2 or 3 columns. |
| `sections/before-after.liquid` | Two photos with a drag slider between them. Works with mouse, touch and keyboard (arrow keys, Home, End). |
| `sections/testimonials.liquid` | Quote cards. Each card starts with "Add a real review you have permission to use." Cards that still say that show only in the theme editor, never on your live store. |
| `sections/faq-accordion.liquid` | Questions that open and close, plus FAQ structured data for search engines built from the same questions. |
| `sections/announcement-marquee.liquid` | Scrolling announcement strip with a Pause / Play button shoppers can reach with the keyboard. Also pauses on hover and focus, and stays still for shoppers who turn on reduced motion. |
| `sections/email-signup.liquid` | Email signup using Shopify's own customer form. Says what people get and always shows "Unsubscribe anytime." No pre-checked boxes. Signups land in Customers with the tag `newsletter`. |

## Good to know

- **Your brand color is already in.** Every section has a brand color setting. Button and strip text switches between dark and light by itself so it stays readable.
- **Nothing loads from outside your store.** No fonts, scripts or images from other sites. Icons are inline SVG. Your images come from your own Shopify files.
- **Styles stay inside each section.** CSS is scoped to the section's id, so it won't change the rest of your theme. Headings use your theme's heading font.
- **Motion is gentle and optional.** Hover lifts and fade-ins switch off when a shopper's device asks for reduced motion.
- **Testimonials:** add a real review you have permission to use, copied exactly. Say so if a review was gifted or paid for. Never write one yourself.
- **FAQ structured data:** keep it on for one FAQ section per page. The answers must match what shoppers can read on the page.

See `INSTALL.md` for the steps.
