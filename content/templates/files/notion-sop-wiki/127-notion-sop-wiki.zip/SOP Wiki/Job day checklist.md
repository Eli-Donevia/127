# SOP: Job day checklist

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Do every job to the same standard, whoever does it.

**When to use it:** The morning of every job.

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Check the calendar, address and notes for today's jobs.
2. Pack the kit using the kit list: [link or list].
3. Arrive [5 minutes] early. Message the client if you'll be late.
4. Do the work in the usual order: [step one], [step two], [step three].
5. Walk the client through what was done, or leave a short note and photo.
6. Take a before and after photo for your records (ask before posting any).

## Done looks like

The work matches the checklist, the client knows it's done and photos are saved.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
