# SOP: End-of-week close-out

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Start every week with clean books, a stocked kit and a clear calendar.

**When to use it:** Every [Friday afternoon].

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Check every job this week has an invoice, and chase anything unpaid.
2. Restock supplies using the kit list. Order anything running low.
3. Reply to any open messages and inquiries.
4. Look at next week's calendar and confirm every job.
5. Back up photos and files.
6. Write down one thing that went wrong and one that went well.

## Done looks like

Books are current, the kit is full, next week is confirmed and nothing is waiting on a reply.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
