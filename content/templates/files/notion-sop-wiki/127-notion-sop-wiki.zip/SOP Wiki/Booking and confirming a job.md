# SOP: Booking and confirming a job

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Turn a yes into a booked, confirmed job with no back and forth.

**When to use it:** A client says yes or books through the booking link.

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Confirm the date, time, address and price in writing.
2. Send the deposit or payment link if you take one: [link].
3. Add the job to the calendar with the address and any access notes.
4. Send a reminder [the day before], with what to expect and how to reach you: [your phone]
5. Note anything special (pets, parking, allergies) in the client record.

## Done looks like

The job is on the calendar, the client has a written confirmation and a reminder is set.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
