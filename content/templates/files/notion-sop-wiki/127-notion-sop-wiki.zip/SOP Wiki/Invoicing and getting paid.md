# SOP: Invoicing and getting paid

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Get paid on time without awkward chasing.

**When to use it:** A job is finished, or on the agreed billing day.

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Send the invoice [the same day] from [your invoicing tool].
2. Include the date, what was done, the price and how to pay.
3. Payment terms: [due on receipt / within 7 days].
4. If it's unpaid after the due date, send a friendly reminder. Repeat after [7 days].
5. Mark it paid and record it in your books.

## Done looks like

Every finished job has an invoice, and every invoice is marked paid or has a reminder date.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
