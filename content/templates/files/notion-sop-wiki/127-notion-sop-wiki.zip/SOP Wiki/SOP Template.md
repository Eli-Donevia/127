# SOP: [Task name]

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [name] | [name] | [date] | 90 days |

**Purpose:** [One sentence: why this task matters and what it protects.]

**When to use it:** [The trigger. "Every time a new booking comes in" or "Every Friday at 3pm".]

## What you need

- [Tool, template or login]
- [Saved reply, checklist or link]

## Steps

1. [Start with a verb. One action per step.]
2. [Put the link or saved reply right in the step.]
3. [Say what "good" looks like if it isn't obvious.]
4. [Add a time limit where it matters: "within 2 hours".]
5. [Last step: how you know it's finished.]

## Done looks like

[What is true when this is done right. Someone else should be able to check it.]

## Common problems

- **[Problem]:** [what to do]
- **[Problem]:** [what to do]

## Notes and changes

- [date]: [what changed and why]
