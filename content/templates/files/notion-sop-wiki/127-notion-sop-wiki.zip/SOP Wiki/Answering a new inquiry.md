# SOP: Answering a new inquiry

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Reply to every new question or quote request quickly and the same way, so no one slips through.

**When to use it:** A new message, call, form or DM asks about prices, dates or what you do.

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Reply within [2 business hours] with a short, friendly answer. Use a saved reply if you have one.
2. Ask the two questions you need to quote: [what they need] and [when they need it].
3. Add them to your contacts list or CRM with where they found you.
4. Send your price or booking link: [your booking link]
5. If there's no reply in [2 days], follow up once. After a second follow-up, mark it closed.

## Done looks like

They have an answer and a next step, and they're in the CRM with a follow-up date.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
