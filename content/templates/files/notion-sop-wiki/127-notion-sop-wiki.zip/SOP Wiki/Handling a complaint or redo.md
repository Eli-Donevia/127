# SOP: Handling a complaint or redo

| Owner | Backup | Last reviewed | Review every |
|---|---|---|---|
| [Your name] | [name] | [date] | 90 days |

**Purpose:** Fix problems fast and fairly, and learn from them.

**When to use it:** A client says something wasn't right.

## What you need

- [Tool, template or login]
- [Saved reply or checklist]

## Steps

1. Reply within [the same day]. Thank them for telling you.
2. Ask what happened and what would make it right. Don't argue the details.
3. Offer the fix you can stand behind: [redo, partial refund, credit].
4. Do the fix and confirm with the client that it's sorted.
5. Write one line in the Notes of this SOP on what caused it, and update a step if needed.

## Done looks like

The client has a reply, a fix and a confirmation, and the cause is written down.

## Common problems

- **[Problem]:** [what to do]

## Notes and changes

- [date]: First version written for [Your business].
