# [Your business] SOP Wiki

*How we do things here, written down once so anyone can do them the same way. SOP means standard operating procedure: a short checklist for a task you repeat.*

## Start here

- [SOP Template](SOP%20Wiki/SOP%20Template.md): copy this for every new SOP.
- [SOP Owners and review dates](SOP%20Wiki/SOP%20Owners.csv): who owns each SOP and when it's next checked.

## Our SOPs

- [Answering a new inquiry](SOP%20Wiki/Answering%20a%20new%20inquiry.md)
- [Booking and confirming a job](SOP%20Wiki/Booking%20and%20confirming%20a%20job.md)
- [Job day checklist](SOP%20Wiki/Job%20day%20checklist.md)
- [Invoicing and getting paid](SOP%20Wiki/Invoicing%20and%20getting%20paid.md)
- [Handling a complaint or redo](SOP%20Wiki/Handling%20a%20complaint%20or%20redo.md)
- [End-of-week close-out](SOP%20Wiki/End-of-week%20close-out.md)

## How this wiki works

1. **One SOP per repeated task.** If you've done it three times, write it down.
2. **Write it for someone new.** A helper on their first day should be able to follow it without asking.
3. **Steps, not essays.** Numbered steps, one action each. Put links and saved replies right in the step.
4. **Every SOP has an owner.** The owner keeps it current and says yes to changes.
5. **Review every 90 days.** Check the SOP Owners table on the first Monday of each month.

## When something goes wrong

Fix the problem first. Then open the SOP, change the step that caused it, and add a line under Notes and changes.

*Questions about an SOP: ask [Your name] at [you@yourbusiness.com].*
