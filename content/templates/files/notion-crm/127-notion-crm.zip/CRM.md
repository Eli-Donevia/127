# [Your business] CRM

*Every person you might work with, every open deal and every conversation, in one place. Kept by [Your name].*

## Open these

- [Contacts](CRM/Contacts.csv): people, how you met them and when you last spoke.
- [Deals](CRM/Deals.csv): each possible job or sale, with stage, value, next step date and source.
- [Activities](CRM/Activities.csv): calls, emails, messages and meetings, logged the day they happen.

## Three rules that keep it useful

1. Every open deal has a next step and a date. No date means it gets forgotten.
2. Log an activity the same day, in a line or two. Write what they said, in their words.
3. When a deal is won or lost, write one line on why. That line is how you get better.

## Stages

| Stage | What it means | Moves on when |
|---|---|---|
| New | They reached out or you met them | You've had a real conversation |
| Talking | You know what they need | You've sent a price or proposal |
| Proposal sent | They have your price in writing | They say yes or no |
| Won | They said yes and booked or paid | |
| Lost | They said no, or went quiet after two follow-ups | |

## Monday, 15 minutes

- [ ] Open Deals, sort by Next step date. Anything overdue: do it today or give it a new date.
- [ ] Move any deal whose stage changed.
- [ ] Add new people from last week to Contacts, with a Source.
- [ ] Look at Source on this month's deals. Note which channel started the most conversations.

## About the example rows

Rows marked (example) are made up to show how to fill things in. Delete them once you add your own.

*Last set up: [date]*
