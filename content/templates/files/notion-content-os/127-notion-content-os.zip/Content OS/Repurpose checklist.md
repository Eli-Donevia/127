# Repurpose checklist

*Run this after a post is live. Most posts can become 3 to 5 more pieces with small changes.*

**Post:** [paste the link]

## Before you start

- [ ] Pick the one idea the post is really about, in one sentence.
- [ ] Save the original file (video, images or text) where you can find it.

## Turn it into

- [ ] **Short video** (TikTok, Reels, Shorts): the hook plus the single best point, under 45 seconds.
- [ ] **Carousel**: one point per slide, hook on slide one, a clear last slide.
- [ ] **Email**: tell the story behind the post and link to it.
- [ ] **Text post** (LinkedIn, Threads, Facebook): the main point as a short story or list.
- [ ] **Pin or blog**: the how-to steps written out, with one photo.
- [ ] **FAQ or website**: if it answers a customer question, add the answer to your site.

## Each version

- [ ] New first line written for that platform.
- [ ] Captions on videos.
- [ ] One clear next step (follow, reply, visit the link).
- [ ] Logged in Posts under Repurposed to.

## Next time

- [ ] Note which version got the most replies or saves, and why you think so.
