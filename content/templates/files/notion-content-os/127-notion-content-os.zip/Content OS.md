# [Your business] Content OS

*Ideas in, posts out. One place to catch ideas, plan posts, keep hooks that work and turn one post into five.*

**Who we make this for:** [Who it's for]

**Where we post:** Instagram [@yourhandle] · TikTok [@yourhandle] · YouTube [your channel]

## Open these

- [Ideas](Content%20OS/Ideas.csv): every idea, the moment you have it. No judging yet.
- [Posts](Content%20OS/Posts.csv): ideas you picked, with status, platform, hook and publish date.
- [Hooks](Content%20OS/Hooks.csv): first lines that make people stop, as fill-in-the-blank patterns.
- [Repurpose checklist](Content%20OS/Repurpose%20checklist.md): turn one finished post into several.

## How it flows

1. **Catch.** Any idea goes into Ideas with a Pillar. Customer questions are the best source.
2. **Pick.** Once a week, move the best ideas into Posts as Drafting.
3. **Hook.** Pick a pattern from Hooks and write the first line before anything else.
4. **Make and schedule.** Set Status to Scheduled and add the Publish date.
5. **Repurpose.** After it's live, run the Repurpose checklist and log where it went.

## Content pillars

| Pillar | What goes here |
|---|---|
| Teach | How-tos and answers to questions customers ask |
| Behind the scenes | How the work gets done, tools, process, mistakes |
| Customer questions | One real question, answered in one post |
| Personal | Why you started, what you care about, your day |

## Weekly batch (60 to 90 minutes)

- [ ] Clear Ideas: pick 3 to 5 for this week, park the rest.
- [ ] Write hooks for each one first.
- [ ] Make the posts in one sitting.
- [ ] Schedule them and fill in Publish date.
- [ ] Repurpose last week's best post.

*Example rows say (example). Replace them with your own.*
